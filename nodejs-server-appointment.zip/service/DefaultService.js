'use strict';


/**
 * Delete a appointment by service_id
 *
 * service_id Integer 
 * no response value expected for this operation
 **/
exports.appointmentIdDELETE = function(service_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update appointment by service_id
 *
 * body Appointment 
 * service_id Integer 
 * no response value expected for this operation
 **/
exports.appointmentIdPUT = function(body,service_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * create a new appointment
 *
 * body Appointment 
 * no response value expected for this operation
 **/
exports.appointmentPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get All appointments Details
 *
 * returns List
 **/
exports.appointment_resGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "date" : "2023-10-07T00:00:00.000+00:00",
  "etime" : "10:00:00",
  "description" : "Discuss project details",
  "stime" : "09:00:00",
  "location" : "office ABC",
  "id" : 1,
  "cusname" : "Jhon devid",
  "title" : "Meeting with client"
}, {
  "date" : "2023-10-07T00:00:00.000+00:00",
  "etime" : "10:00:00",
  "description" : "Discuss project details",
  "stime" : "09:00:00",
  "location" : "office ABC",
  "id" : 1,
  "cusname" : "Jhon devid",
  "title" : "Meeting with client"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get a appointment by service_id
 *
 * service_id Integer 
 * returns Appointment
 **/
exports.appointment_resService_idGET = function(service_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2023-10-07T00:00:00.000+00:00",
  "etime" : "10:00:00",
  "description" : "Discuss project details",
  "stime" : "09:00:00",
  "location" : "office ABC",
  "id" : 1,
  "cusname" : "Jhon devid",
  "title" : "Meeting with client"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete a appointment by all
 *
 * no response value expected for this operation
 **/
exports.appointmentsBulk_DELETE = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a appointment by customer name
 *
 * cusname String 
 * returns Appointment
 **/
exports.appointmentsBy_customerGET = function(cusname) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2023-10-07T00:00:00.000+00:00",
  "etime" : "10:00:00",
  "description" : "Discuss project details",
  "stime" : "09:00:00",
  "location" : "office ABC",
  "id" : 1,
  "cusname" : "Jhon devid",
  "title" : "Meeting with client"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get a appointment by time period
 *
 * stime String 
 * etime String 
 * returns Appointment
 **/
exports.appointmentsIn_time_periodGET = function(stime,etime) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2023-10-07T00:00:00.000+00:00",
  "etime" : "10:00:00",
  "description" : "Discuss project details",
  "stime" : "09:00:00",
  "location" : "office ABC",
  "id" : 1,
  "cusname" : "Jhon devid",
  "title" : "Meeting with client"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Customer name of the appointment
 *
 * service_id Integer 
 * cusname String Name of customer that needs to be updated (optional)
 * stime String New appointment start time that needs to be updated (optional)
 * etime String New appointment end time that needs to be updated (optional)
 * no response value expected for this operation
 **/
exports.updateoppointmentWithNewName = function(service_id,cusname,stime,etime) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

