'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.appointmentIdDELETE = function appointmentIdDELETE (req, res, next, service_id) {
  Default.appointmentIdDELETE(service_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentIdPUT = function appointmentIdPUT (req, res, next, body, service_id) {
  Default.appointmentIdPUT(body, service_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentPOST = function appointmentPOST (req, res, next, body) {
  Default.appointmentPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointment_resGET = function appointment_resGET (req, res, next) {
  Default.appointment_resGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointment_resService_idGET = function appointment_resService_idGET (req, res, next, service_id) {
  Default.appointment_resService_idGET(service_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsBulk_DELETE = function appointmentsBulk_DELETE (req, res, next) {
  Default.appointmentsBulk_DELETE()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsBy_customerGET = function appointmentsBy_customerGET (req, res, next, cusname) {
  Default.appointmentsBy_customerGET(cusname)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsIn_time_periodGET = function appointmentsIn_time_periodGET (req, res, next, stime, etime) {
  Default.appointmentsIn_time_periodGET(stime, etime)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateoppointmentWithNewName = function updateoppointmentWithNewName (req, res, next, service_id, cusname, stime, etime) {
  Default.updateoppointmentWithNewName(service_id, cusname, stime, etime)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
